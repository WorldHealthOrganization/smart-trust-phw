# DVC HCERT Payload - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC HCERT Payload**

## Logical Model: DVC HCERT Payload ( Abstract ) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCMin | *Version*:0.1.0 |
| Active as of 2026-10-23 | *Computable Name*:DVCMin |

 
Minimal DVC payload for use within an HCERT Payload 

**Usages:**

* Derived from this Logical Model: [DVCMinPreQual](StructureDefinition-DVCMinPreQual.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/smart.who.int.trust-phw|current/StructureDefinition/StructureDefinition-DVCMin.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-DVCMin.csv), [Excel](StructureDefinition-DVCMin.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "DVCMin",
  "url" : "http://smart.who.int/trust-phw/StructureDefinition/DVCMin",
  "version" : "0.1.0",
  "name" : "DVCMin",
  "title" : "DVC HCERT Payload",
  "status" : "active",
  "date" : "2026-10-23T08:56:40+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Minimal DVC payload for use within an HCERT Payload",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "logical",
  "abstract" : true,
  "type" : "http://smart.who.int/trust-phw/StructureDefinition/DVCMin",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "DVCMin",
      "path" : "DVCMin",
      "short" : "DVC HCERT Payload",
      "definition" : "Minimal DVC payload for use within an HCERT Payload"
    },
    {
      "id" : "DVCMin.n",
      "path" : "DVCMin.n",
      "code" : [{
        "system" : "http://smart.who.int/trust-phw/CodeSystem/ICVP.Core",
        "code" : "ICVP.A9.DE.1"
      },
      {
        "system" : "http://loinc.org",
        "code" : "87226-7",
        "display" : "Legal name of patient - first and last"
      }],
      "short" : "Name",
      "definition" : "Name",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "DVCMin.dob",
      "path" : "DVCMin.dob",
      "code" : [{
        "system" : "http://smart.who.int/trust-phw/CodeSystem/ICVP.Core",
        "code" : "ICVP.A9.DE.2"
      },
      {
        "system" : "http://loinc.org",
        "code" : "21112-8",
        "display" : "Birth date"
      },
      {
        "system" : "http://snomed.info/sct",
        "code" : "184099003",
        "display" : "Date of birth (observable entity)"
      }],
      "short" : "Date of birth",
      "definition" : "Date of birth",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "DVCMin.s",
      "path" : "DVCMin.s",
      "code" : [{
        "system" : "http://smart.who.int/trust-phw/CodeSystem/ICVP.Core",
        "code" : "ICVP.A9.DE.3"
      }],
      "short" : "Sex",
      "definition" : "Sex",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.org/fhir/administrative-gender"
      }
    },
    {
      "id" : "DVCMin.nt",
      "path" : "DVCMin.nt",
      "code" : [{
        "system" : "http://smart.who.int/trust-phw/CodeSystem/ICVP.Core",
        "code" : "ICVP.A9.DE.8"
      },
      {
        "system" : "http://loinc.org",
        "code" : "69433-1",
        "display" : "Citizenship status"
      },
      {
        "system" : "http://snomed.info/sct",
        "code" : "223369002",
        "display" : "Country (geographic location)"
      }],
      "short" : "Nationality",
      "definition" : "Nationality",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.org/fhir/ValueSet/iso3166-1-3"
      }
    },
    {
      "id" : "DVCMin.id",
      "path" : "DVCMin.id",
      "code" : [{
        "system" : "http://smart.who.int/trust-phw/CodeSystem/ICVP.Core",
        "code" : "ICVP.A9.DE.9"
      },
      {
        "system" : "http://loinc.org",
        "code" : "76435-7",
        "display" : "Patient identifier"
      },
      {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000474003",
        "display" : "Universally Unique Identifier (foundation metadata concept)"
      }],
      "short" : "National Identification Document",
      "definition" : "National Identification Document",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "DVCMin.dt",
      "path" : "DVCMin.dt",
      "short" : "National ID Document Type",
      "definition" : "National ID Document Type",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://terminology.hl7.org/ValueSet/v2-0203"
      }
    },
    {
      "id" : "DVCMin.gn",
      "path" : "DVCMin.gn",
      "code" : [{
        "system" : "http://smart.who.int/trust-phw/CodeSystem/ICVP.Core",
        "code" : "ICVP.A9.DE.10"
      },
      {
        "system" : "http://loinc.org",
        "code" : "79183-0",
        "display" : "First name of Guardian or legally authorized representative"
      },
      {
        "system" : "http://snomed.info/sct",
        "code" : "394619001",
        "display" : "Guardian (person)"
      }],
      "short" : "Parent or Guardian Name",
      "definition" : "Parent or Guardian Name",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "DVCMin.vx",
      "path" : "DVCMin.vx",
      "short" : "Vaccine Details",
      "definition" : "Vaccine Details",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "http://smart.who.int/trust-phw/StructureDefinition/DVCMinVaccineDetails"
      }]
    },
    {
      "id" : "DVCMin.v",
      "path" : "DVCMin.v",
      "code" : [{
        "system" : "http://smart.who.int/trust-phw/CodeSystem/ICVP.Core",
        "code" : "ICVP.D5.DE.27"
      }],
      "short" : "Version",
      "definition" : "Version of the certificate template",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
