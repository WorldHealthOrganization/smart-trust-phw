# Home - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/ImplementationGuide/smart.who.int.trust-phw | *Version*:0.1.0 |
| Draft as of 2026-10-20 | *Computable Name*:trust-phw |

 This DAK and set of implementation tools are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This WHO **[insert health domain here]** DAK **add content here**

### L1 Narrative guidelines

**[insert content here]**

### L2 Operational guidelines

The L2 **[insert health domain here]** Digital adaptation kit publications and implementations tools can be found here:

* [Published DAK Document]()
* [Link to core data dictionary]()
* [Link to decision support logic]()
* [Link to scheduling logic]()
* [Link to indicators table]()
* [Link to functional and non functional requirements]()

### L3 Machine readable guidelines

The L3 FHIR Implementation Guide for the **[insert health domain here]** SMART Guidelines is yet to be published. Links will be published here as soon as they're available.

### L4 Executable guidelines

Reference implementations representing the L4 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### L5 Dynamic guidelines

Content representing the L5 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### News

### Contact Us

Please let us know about your experience in using the DAK and questions you may have by contacting us at [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)

### License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO License](http://creativecommons.org/licenses/by-nc-sa/3.0/igo/).

![](https://i.creativecommons.org/l/by-nc-sa/3.0/igo/88x31.png)

### Providing Feedback

 Feedback specific to this specification can provided through: 

* Clicking on one of the Feedbacks link to the right of any section header
* Sending an email to [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)
* Creating an issue on GitHub [trust-phw repository](https://github.com/WorldHealthOrganization/trust-phw)

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This implementation guide includes a machine-readable representation of WHO guidelines for **[insert health domain here]**, as documented in the WHO Digital Adaptation Kit for **[insert health domain here]** (link forthcoming) and explicitly encodes computer-interoperable logic, including data models, terminologies, and logic expressions, in a computable language to support implementation of **[insert health domain here]** use cases by WHO Member States.

The guide is part of the [WHO SMART Guidelines approach](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) to support countries to integrate WHO global health and data recommendations into digital systems accurately and consistently. It defines a series of FHIR Resources, Profiles, Extensions, and Terminology based on the WHO **[insert health domain here]** Digital Adaptation Kit (link forthcoming).

Supporting guidance, recommendations, resources, and standards are included in the [References](references.md) and [Dependencies](dependencies.md).

### About this implementation guide

This implementation guide is broken into the following levels of [knowledge representation](https://hl7.org/fhir/uv/cpg/documentation-approach-06-01-levels-of-knowledge-representation.html):

* [Home](index.md) - contains references to the guidance, guidelines, policies and recommendations underpinning this implementation guide.
* [Business Requirements](business-requirements.md) - contains the requirements for this implementation guide including the definition of key concepts, use cases, and a data dictionary.
* [Data Models and Exchange](data-models-and-exchange.md) - contains the data models and data exchange protocols with actors and transactions defined.
* [Deployment Guidance ](deployment.md) - contains relevant technical specifications and guidance, testing resources, reference implementation materials, and supporting guidance for adaptation to local contexts.

This guide is prepared to facilitate digital implementation of WHO **[insert health domain here]** guidelines by providing FHIR-based computable representations of and implementation guidance for using the key components of the WHO **[insert health domain here]** digital adaptation kit (DAK):

* Health Interventions & Recommendations
* Generic Personas
* User Scenarios
* Business Processes & Workflows
* Core Data Elements
* Decision Support Logic
* Indicators & Monitoring
* Functional & Non-functional Requirements

This guide is a companion to the Digital Adaptation Kit (DAK) and should be used side-by-side with it. Implementers are strongly encouraged to make use of the Digital Adaptation Kit. The focus of this guide is on the explanation and use of the computable artifacts.

This guide assumes use of the following resources:

* [IPS Patient](http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips)
* [CPG ActivityDefinitions](https://hl7.org/fhir/uv/cpg/artifacts.html#activitydefinition-index)
* For a complete listing of the artifacts defined in this implementation guide, refer to the [Artifact Index](artifacts.md).
* A complete offline copy of this implementation guide can be found on the [Downloads](downloads.md) page.
* This Implementation Guide makes use of [Clinical Quality Language](https://cql.hl7.org/) for the decision support artifacts including the PlanDefinitions and Measures. They are used to express how a calculation should occur and can be used with a CQL engine in order to process the decision or indicator directly from the applicable FHIR resources. Links to this specification, the FHIR Clinical Practice Guidelines Speciciation, and other helpful resources can be found in the Support dropdown.

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

### Dependencies

### Cross Version Analysis

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.4.0/CodeSystem-ISO3166Part1.html): [DVC](StructureDefinition-DVC.md), [DVCMin](StructureDefinition-DVCMin.md) and [Questionnaire/PreQual](Questionnaire-PreQual.md)


* The WHO grants a license for "commercial and non-commercial use" of ICD-11CC BY-ND 3.0 IGODetailed information can be found here: [https://icd.who.int/en/docs/icd11-license.pdf](https://icd.who.int/en/docs/icd11-license.pdf) Contact licensing@who.int to obtain further information.

* [International Classification of Diseases, 11th Revision Mortality and Morbidity Statistics (MMS)](http://terminology.hl7.org/6.4.0/CodeSystem-ICD11MMS.html): [DVCVaccines](ValueSet-DVCVaccines.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.4.0/CodeSystem-v3-loinc.html): [Bundle/DVCDocExample](Bundle-DVCDocExample.md), [Bundle/DVCDocSDExample](Bundle-DVCDocSDExample.md)... Show 14 more, [Composition-uv-ips-DVC](StructureDefinition-Composition-uv-ips-DVC.md), [Composition-uv-ips-PreQual](StructureDefinition-Composition-uv-ips-PreQual.md), [DVC](StructureDefinition-DVC.md), [DVCComposition](StructureDefinition-DVCComposition.md), [DVCMin](StructureDefinition-DVCMin.md), [DVCMinPreQual](StructureDefinition-DVCMinPreQual.md), [DVCMinVaccineDetails](StructureDefinition-DVCMinVaccineDetails.md), [DVCMinVaccineDetailsPreQual](StructureDefinition-DVCMinVaccineDetailsPreQual.md), [DVCPreQual](StructureDefinition-DVCPreQual.md), [DVCSD](StructureDefinition-DVCSD.md), [DVCSDComposition](StructureDefinition-DVCSDComposition.md), [DVCVaccineDetails](StructureDefinition-DVCVaccineDetails.md), [DVCVaccineDetailsPreQual](StructureDefinition-DVCVaccineDetailsPreQual.md) and [VaccineDetailsSD](StructureDefinition-VaccineDetailsSD.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* SNOMED Clinical Terms&reg; (SNOMED CT&reg;): [DVC](StructureDefinition-DVC.md), [DVCMin](StructureDefinition-DVCMin.md)... Show 8 more, [DVCMinPreQual](StructureDefinition-DVCMinPreQual.md), [DVCMinVaccineDetails](StructureDefinition-DVCMinVaccineDetails.md), [DVCMinVaccineDetailsPreQual](StructureDefinition-DVCMinVaccineDetailsPreQual.md), [DVCPreQual](StructureDefinition-DVCPreQual.md), [DVCSD](StructureDefinition-DVCSD.md), [DVCVaccineDetails](StructureDefinition-DVCVaccineDetails.md), [DVCVaccineDetailsPreQual](StructureDefinition-DVCVaccineDetailsPreQual.md) and [VaccineDetailsSD](StructureDefinition-VaccineDetailsSD.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [administrativeSex](http://terminology.hl7.org/7.3.0/CodeSystem-v2-0001.html): [Questionnaire/PreQual](Questionnaire-PreQual.md)
* [identifierType](http://terminology.hl7.org/7.3.0/CodeSystem-v2-0203.html): [Bundle/DVCDocExample](Bundle-DVCDocExample.md), [Bundle/DVCDocSDExample](Bundle-DVCDocSDExample.md), [DVC](StructureDefinition-DVC.md), [DVCMin](StructureDefinition-DVCMin.md) and [Questionnaire/PreQual](Questionnaire-PreQual.md)
* [ActClass](http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActClass.html): [Composition-uv-ips-DVC](StructureDefinition-Composition-uv-ips-DVC.md) and [Composition-uv-ips-PreQual](StructureDefinition-Composition-uv-ips-PreQual.md)


