# Dependencies - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Home**](index.md)
* **Dependencies**

## Dependencies

The following standards and profiles are referenced in this implementation guide:

* Integrating the Healthcare Enterprise (IHE):
* The International Patient Summary (IPS):
* World Health Organization (WHO):

