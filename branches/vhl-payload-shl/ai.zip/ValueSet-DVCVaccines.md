# DVC - Vaccines - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - Vaccines**

## ValueSet: DVC - Vaccines 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/ValueSet/DVCVaccines | *Version*:0.1.0 |
| Active as of 2026-10-20 | *Computable Name*:DVCVaccines |

 
This value set includes codes from ICD 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### DVC - Vaccines Schema API

JSON Schema for DVC - Vaccines ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-DVCVaccines.schema.json

#### JSON Schema definition for the enumeration ValueSet-DVCVaccines

This endpoint serves the JSON Schema definition for the enumeration ValueSet-DVCVaccines.

## Schema Definition

### ValueSet-DVCVaccines

**Description:** JSON Schema for DVC - Vaccines ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "DVCVaccines",
  "url" : "http://smart.who.int/trust-phw/ValueSet/DVCVaccines",
  "version" : "0.1.0",
  "name" : "DVCVaccines",
  "title" : "DVC - Vaccines",
  "status" : "active",
  "date" : "2026-10-20T18:49:23+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "This value set includes codes from ICD",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://id.who.int/icd/release/11/mms",
      "concept" : [{
        "code" : "XM4639",
        "display" : "Tuberculosis vaccines"
      },
      {
        "code" : "XM8142",
        "display" : "Tuberculosis, live attenuated vaccines"
      },
      {
        "code" : "XM29K4",
        "display" : "Cholera vaccines"
      },
      {
        "code" : "XM3Z26",
        "display" : "Cholera, inactivated, whole cell vaccines"
      },
      {
        "code" : "XM72A0",
        "display" : "Cholera, live attenuated vaccines"
      },
      {
        "code" : "XM1FT6",
        "display" : "Cholera, combinations with typhoid vaccine, inactivated, whole cell vaccines"
      },
      {
        "code" : "XM8AW3",
        "display" : "Diphtheria vaccines"
      },
      {
        "code" : "XM9744",
        "display" : "Diphtheria, rubella, tetanus vaccines"
      },
      {
        "code" : "XM31Q8",
        "display" : "Tetanus, diphtheria, acellular pertussis"
      },
      {
        "code" : "XM8AW1",
        "display" : "Diphtheria, poliomyelitis, tetanus vaccines"
      },
      {
        "code" : "XM09Q7",
        "display" : "Diphtheria, pertussis, poliomyelitis, tetanus vaccines"
      },
      {
        "code" : "XM41N3",
        "display" : "Diphtheria, hepatitis B, pertussis, tetanus vaccines"
      },
      {
        "code" : "XM1LX9",
        "display" : "Diphtheria, hemophilus influenzae B, pertussis, poliomyelitis, tetanus vaccines"
      },
      {
        "code" : "XM3G68",
        "display" : "Diphtheria, hepatitis B, tetanus vaccines"
      },
      {
        "code" : "XM0LT9",
        "display" : "Diphtheria, pertussis, poliomyelitis, tetanus, hepatitis B vaccines"
      },
      {
        "code" : "XM7JP3",
        "display" : "Diphtheria, hemophilus influenzae B, pertussis, tetanus, hepatitis B vaccines"
      },
      {
        "code" : "XM5XP9",
        "display" : "Diphtheria, hemophilus influenzae B, pertussis, tetanus-hepatitis B, meningococcus A + C vaccines"
      },
      {
        "code" : "XM1G86",
        "display" : "Tetanus toxoid, combinations with diphtheria toxoid vaccines"
      },
      {
        "code" : "XM32Q5",
        "display" : "Tetanus and diphtheria vaccines"
      },
      {
        "code" : "XM2CV8",
        "display" : "Vaccines pertussis with diphtheria"
      },
      {
        "code" : "XM21E6",
        "display" : "Diphtheria tetanus, acellular pertussis, inactivated polio virus, haemophilus Influenzae type B vaccines"
      },
      {
        "code" : "XM84S1",
        "display" : "Diphtheria, hepatitis B, tetanus, acellular pertussis, inactivated polio virus, haemophilus Influenzae type B vaccines"
      },
      {
        "code" : "XM9JP8",
        "display" : "Diphtheria, tetanus, acellular pertussis, inactivated polio virus vaccines"
      },
      {
        "code" : "XM46V1",
        "display" : "Diphtheria vaccines combination including pertussis"
      },
      {
        "code" : "XM4039",
        "display" : "Vaccines diphtheria with tetanus"
      },
      {
        "code" : "XM11V3",
        "display" : "Haemophilus influenzae B vaccines"
      },
      {
        "code" : "XM01H1",
        "display" : "Hemophilus influenzae B and poliomyelitis vaccines"
      },
      {
        "code" : "XM32L7",
        "display" : "Hemophilus influenzae B and hepatitis B vaccines"
      },
      {
        "code" : "XM6LL6",
        "display" : "Hepatitis vaccines"
      },
      {
        "code" : "XM2A12",
        "display" : "Hepatitis A, inactivated, whole virus"
      },
      {
        "code" : "XM3JA6",
        "display" : "Typhoid, hepatitis A vaccines"
      },
      {
        "code" : "XM03Y7",
        "display" : "Combinations hepatitis vaccines"
      },
      {
        "code" : "XM9V38",
        "display" : "Hepatitis B, purified antigen"
      },
      {
        "code" : "XM9QP0",
        "display" : "Papillomavirus vaccine"
      },
      {
        "code" : "XM1821",
        "display" : "Papillomavirus (human types 6,11,16,18)"
      },
      {
        "code" : "XM9BT4",
        "display" : "Papillomavirus (human types 16,18)"
      },
      {
        "code" : "XM5CE9",
        "display" : "Papillomavirus (human types 6,11,16,18,31,33,45,52,58)"
      },
      {
        "code" : "XM0LB5",
        "display" : "Encephalitis, Japanese, inactivated, whole virus"
      },
      {
        "code" : "XM47S0",
        "display" : "Encephalitis, Japanese, live attenuated"
      },
      {
        "code" : "XM28X5",
        "display" : "Measles vaccines"
      },
      {
        "code" : "XM8L15",
        "display" : "Measles, live attenuated"
      },
      {
        "code" : "XM8TF3",
        "display" : "Measles, combinations with mumps and rubella, live attenuated"
      },
      {
        "code" : "XM21H2",
        "display" : "Measles, combinations with rubella, live attenuated"
      },
      {
        "code" : "XM4AJ8",
        "display" : "Measles, combinations with mumps, rubella and varicella, live attenuated"
      },
      {
        "code" : "XM9439",
        "display" : "Measles, combinations with mumps, live attenuated"
      },
      {
        "code" : "XM2WV4",
        "display" : "Meningococcal vaccines"
      },
      {
        "code" : "XM92B2",
        "display" : "Meningococcal monovalent purified polysaccharides antigen vaccines"
      },
      {
        "code" : "XM5LC2",
        "display" : "Meningococcal polyvalent purified polysaccharides antigen vaccines"
      },
      {
        "code" : "XM18Y8",
        "display" : "Meningococcus C, purified polysaccharides antigen conjugated vaccines"
      },
      {
        "code" : "XM2280",
        "display" : "Meningococcus A, purified polysaccharides antigen conjugated vaccines"
      },
      {
        "code" : "XM9GJ1",
        "display" : "Meningococcus B, outer membrane vesicle vaccines"
      },
      {
        "code" : "XM1X81",
        "display" : "Meningococcus B, multicomponent vaccines"
      },
      {
        "code" : "XM37L5",
        "display" : "Meningococcus A, purified polysaccharides antigen vaccines"
      },
      {
        "code" : "XM1131",
        "display" : "Mumps vaccine"
      },
      {
        "code" : "XM2340",
        "display" : "Mumps, live attenuated"
      },
      {
        "code" : "XM3B09",
        "display" : "Rubella, combinations with mumps, live attenuated"
      },
      {
        "code" : "XM43M9",
        "display" : "Pertussis vaccines"
      },
      {
        "code" : "XM45L8",
        "display" : "Pertussis, inactivated, whole cell vaccines"
      },
      {
        "code" : "XM62J1",
        "display" : "Pertussis, purified antigen vaccines"
      },
      {
        "code" : "XM2TK2",
        "display" : "Pertussis, inactivated, whole cell, combinations with toxoids vaccines"
      },
      {
        "code" : "XM4082",
        "display" : "Pertussis, purified antigen, combinations with toxoids vaccines"
      },
      {
        "code" : "XM9EM7",
        "display" : "Pneumococcal vaccines"
      },
      {
        "code" : "XM9G97",
        "display" : "Pneumococcal conjugate (13-valent) vaccines"
      },
      {
        "code" : "XM2249",
        "display" : "Pneumococcal polysaccharide 23-valent vaccines"
      },
      {
        "code" : "XM91D7",
        "display" : "Pneumococcus, purified polysaccharides antigen vaccines"
      },
      {
        "code" : "XM96S7",
        "display" : "Pneumococcus, purified polysaccharides antigen conjugated vaccines"
      },
      {
        "code" : "XM4R39",
        "display" : "Pneumococcus purified polysaccharides antigen and Haemophilus influenzae, conjugated vaccines"
      },
      {
        "code" : "XM0N50",
        "display" : "Poliomyelitis vaccines"
      },
      {
        "code" : "XM5V19",
        "display" : "Poliomyelitis, trivalent, inactivated, whole virus"
      },
      {
        "code" : "XM79H3",
        "display" : "Poliomyelitis oral, bivalent, live attenuated"
      },
      {
        "code" : "XM0VX8",
        "display" : "Poliomyelitis oral, monovalent live attenuated"
      },
      {
        "code" : "XM0KZ1",
        "display" : "Poliomyelitis oral, trivalent, live attenuated"
      },
      {
        "code" : "XM6T09",
        "display" : "Rabies vaccine"
      },
      {
        "code" : "XM7BE8",
        "display" : "Rabies, inactivated, whole virus"
      },
      {
        "code" : "XM1CE0",
        "display" : "Rotavirus diarrhoea vaccines"
      },
      {
        "code" : "XM4GV0",
        "display" : "Rota virus, live attenuated"
      },
      {
        "code" : "XM4VG1",
        "display" : "Rota virus, pentavalent, live, reassorted"
      },
      {
        "code" : "XM7PP1",
        "display" : "Rubella vaccine"
      },
      {
        "code" : "XM9PS9",
        "display" : "Rubella, live attenuated"
      },
      {
        "code" : "XM1LR5",
        "display" : "Influenza vaccines"
      },
      {
        "code" : "XM8857",
        "display" : "Influenza vaccine, inactivated, whole virus"
      },
      {
        "code" : "XM5V64",
        "display" : "Influenza vaccines, live attenuated"
      },
      {
        "code" : "XM8MP2",
        "display" : "Influenza vaccines, inactivated, split virus or surface antigen"
      },
      {
        "code" : "XM9E16",
        "display" : "Influenza vaccines, virus like particle"
      },
      {
        "code" : "XM33X8",
        "display" : "Influenza, purified antigen"
      },
      {
        "code" : "XM5L44",
        "display" : "Tetanus vaccines"
      },
      {
        "code" : "XM29H5",
        "display" : "Tetanus toxoid vaccines"
      },
      {
        "code" : "XM9AK2",
        "display" : "Tetanus toxoid, combinations with tetanus immunoglobulin vaccines"
      },
      {
        "code" : "XM0RC1",
        "display" : "Encephalitis vaccines"
      },
      {
        "code" : "XM8MP6",
        "display" : "Encephalitis, tick borne, inactivated, whole virus"
      },
      {
        "code" : "XM8BU8",
        "display" : "Typhoid vaccines"
      },
      {
        "code" : "XM33K4",
        "display" : "Typhoid, oral, live attenuated vaccines"
      },
      {
        "code" : "XM89G3",
        "display" : "Typhoid, inactivated, whole cell vaccines"
      },
      {
        "code" : "XM3SF6",
        "display" : "Typhoid, purified polysaccharide antigen vaccines"
      },
      {
        "code" : "XM9UB1",
        "display" : "Typhoid-paratyphoid vaccines"
      },
      {
        "code" : "XM8DG3",
        "display" : "Varicella zoster vaccines"
      },
      {
        "code" : "XM0NS8",
        "display" : "Varicella, live attenuated"
      },
      {
        "code" : "XM0N24",
        "display" : "Yellow fever vaccine"
      },
      {
        "code" : "XM3418",
        "display" : "Yellow fever, live attenuated"
      },
      {
        "code" : "XM38G7",
        "display" : "Dengue vaccine"
      },
      {
        "code" : "XM68M6",
        "display" : "COVID-19 vaccines"
      },
      {
        "code" : "XM0GQ8",
        "display" : "COVID-19 vaccine, RNA based"
      },
      {
        "code" : "XM1NL1",
        "display" : "COVID-19 vaccine, inactivated virus"
      },
      {
        "code" : "XM1J92",
        "display" : "COVID-19 vaccine, virus like particle"
      },
      {
        "code" : "XM9QW8",
        "display" : "COVID-19 vaccine, non-replicating viral vector"
      },
      {
        "code" : "XM6AT1",
        "display" : "COVID-19 vaccine, DNA based"
      },
      {
        "code" : "XM5JC5",
        "display" : "COVID-19 vaccine, virus protein subunit"
      },
      {
        "code" : "XM3CT4",
        "display" : "Recombinant SARS-CoV-2 vaccine"
      },
      {
        "code" : "XM0CX4",
        "display" : "COVID-19 vaccine, replicating viral vector"
      },
      {
        "code" : "XM5DF6",
        "display" : "COVID-19 vaccine, live attenuated virus"
      }]
    }]
  }
}

```
