# Table of Contents - GDHCN Trust Network - Personal Health Wallet v0.1.0

* **Table of Contents**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [1.1 Changes](changes.md) |
| [1.2 Dependencies](dependencies.md) |
| [1.3 References](references.md) |
| [1.4 Adapting Guidelines for Country use](adapting.md) |
| [1.5 License](license.md) |
| [2 Business Requirements](business-requirements.md) |
| [2.1 Concepts](concepts.md) |
| [2.2 Generic Personas](personas.md) |
| [2.3 User Scenarios](scenarios.md) |
| [2.4 Business Processes](business-processes.md) |
| [2.5 Data Dictionary](dictionary.md) |
| [2.6 Decision-support logic](decision-logic.md) |
| [2.7 Indicator and Performance Metrics](indicators.md) |
| [2.8 Functional Requirements](functional-requirements.md) |
| [2.9 Non-functional Requirements](non-functional-requirements.md) |
| [3 Data Models and Exchange](data-models-and-exchange.md) |
| [3.1 System Actors](system-actors.md) |
| [3.2 Sequence Diagrams](sequence-diagrams.md) |
| [3.3 Transactions](transactions.md) |
| [3.4 Indicators and Measures](indicators-measures.md) |
| [3.5 Codings](codings.md) |
| [4 Deployment](deployment.md) |
| [4.1 Security and Privacy Considerations](security-privacy.md) |
| [4.2 Testing](testing.md) |
| [4.3 Test Data](test-data.md) |
| [4.4 Reference Implementations](reference-implementations.md) |
| [4.5 Trust Domains](trust_domain.md) |
| [4.6 Downloads](downloads.md) |
| [5 Indices](indices.md) |
| [5.1 Artifact Index](artifacts.md) |
| [5.1.1 Consent Registry](ActorDefinition-ConsentRegistry.md) |
| [5.1.2 Holder](ActorDefinition-Holder.md) |
| [5.1.3 Issuer](ActorDefinition-Issuer.md) |
| [5.1.4 Receiver](ActorDefinition-Receiver.md) |
| [5.1.5 Trust Network Anchor](ActorDefinition-TrustNetworkAnchor.md) |
| [5.1.6 Trust Network Participant](ActorDefinition-TrustNetworkParticipant.md) |
| [5.1.7 Accept mTLS](Requirements-accept-mtls-connection.md) |
| [5.1.8 Distribute PKI material](Requirements-distribute-pki-material.md) |
| [5.1.9 Initiate mTLS](Requirements-initiate-mtls-connection.md) |
| [5.1.10 Provide VHL or VDHC](Requirements-provide-a-vhl-to-a-receiver.md) |
| [5.1.11 Publish PKI material](Requirements-publish-pki-material.md) |
| [5.1.12 Receive PKI material](Requirements-receive-pki-material.md) |
| [5.1.13 Receive VHL or VDHC](Requirements-receive-a-vhl.md) |
| [5.1.14 Retrieve PKI material](Requirements-retrieve-pki-material.md) |
| [5.1.15 DVC](StructureDefinition-DVC.md) |
| [5.1.16 DVC - Vaccine Details](StructureDefinition-VaccineDetails.md) |
| [5.1.17 DVC HCERT Payload](StructureDefinition-DVCMin.md) |
| [5.1.18 DVC HCERT Payload for PreQual DB](StructureDefinition-DVCMinVaccineDetailsPreQual.md) |
| [5.1.19 DVC HCert Vaccine Details (Minimal)](StructureDefinition-DVCMinVaccineDetails.md) |
| [5.1.20 DVC Vaccine Details with Selective Disclosure](StructureDefinition-VaccineDetailsSD.md) |
| [5.1.21 DVCMinPreQual](StructureDefinition-DVCMinPreQual.md) |
| [5.1.22 Health Link Payload (DRAFT)](StructureDefinition-HealthLinkPayload.md) |
| [5.1.23 PreQual](StructureDefinition-PreQualDVC.md) |
| [5.1.24 PreQual - Vaccine Details](StructureDefinition-PreQualVaccineDetails.md) |
| [5.1.25 Smart Health Link (DRAFT)](StructureDefinition-SmartHealthLink.md) |
| [5.1.26 SMART Health Link Payload (DRAFT)](StructureDefinition-SMARTHealthLinkPayload.md) |
| [5.1.27 Verifiable Health Link Payload (DRAFT)](StructureDefinition-VerifiableHealthLinkPayload.md) |
| [5.1.28 DVC Model Questionnaire](Questionnaire-PreQual.md) |
| [5.1.29 Digital Vaccination Certificate - Bundle](StructureDefinition-DVCBundle.md) |
| [5.1.30 Digital Vaccination Certificate - Composition](StructureDefinition-DVCComposition.md) |
| [5.1.31 Digital Vaccination Certificate - Composition](StructureDefinition-DVCSDComposition.md) |
| [5.1.32 DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set](StructureDefinition-Immunization-uv-ips-DVC.md) |
| [5.1.33 DVC - WHO PreQual Immunization for IPS](StructureDefinition-Immunization-uv-ips-PreQual.md) |
| [5.1.34 DVC Certificate - DVC Bundle for Digital Vaccine Certificates](StructureDefinition-Bundle-uv-ips-DVC.md) |
| [5.1.35 DVC Certificate - IPS Bundle for WHO PreQual Databae](StructureDefinition-Bundle-uv-ips-PreQual.md) |
| [5.1.36 DVC Certificate - IPS Composition](StructureDefinition-Composition-uv-ips-DVC.md) |
| [5.1.37 DVC Certificate - IPS Composition for WHO PreQual Database](StructureDefinition-Composition-uv-ips-PreQual.md) |
| [5.1.38 DVC document Bundle with Selective Disclosure](StructureDefinition-DVCSDBundle.md) |
| [5.1.39 DVC Immunization](StructureDefinition-DVCImmunization.md) |
| [5.1.40 DVC Immunization with Selective Disclosure](StructureDefinition-DVCSDImmunization.md) |
| [5.1.41 DVC Patient](StructureDefinition-DVCPatient.md) |
| [5.1.42 DVC Patient with Selective Disclosure](StructureDefinition-DVCSDPatient.md) |
| [5.1.43 DoseNumberCodeableConcept](StructureDefinition-DoseNumberCodeableConcept.md) |
| [5.1.44 SelectiveDisclosure](StructureDefinition-SelectiveDisclosure.md) |
| [5.1.45 SGActorExt](StructureDefinition-SGActorExt.md) |
| [5.1.46 Disclosure Statements](ValueSet-DisclosureStatements.md) |
| [5.1.47 DVC - Vaccines](ValueSet-DVCVaccines.md) |
| [5.1.48 HL.TYPE ValueSet](ValueSet-HL.TYPE.md) |
| [5.1.49 Relationship Status for Contact in Patient](ValueSet-DVCRelationshipStatus.md) |
| [5.1.50 Disclosure Statements](CodeSystem-DisclosureStatements.md) |
| [5.1.51 HL Type CodeSystem](CodeSystem-HL.TYPE.md) |
| [5.1.52 Relationship Status for Contact in Patient](CodeSystem-DVCRelationshipStatus.md) |
| [5.1.53 Smart Guidelines Documentation Section](CodeSystem-DocumentationSections.md) |
| [5.1.54 DVCDocExample](Bundle-DVCDocExample.md) |
| [5.1.55 DVCDocSDExample](Bundle-DVCDocSDExample.md) |
| [5.1.56 DVCExample](Binary-DVCExample.md) |
| [5.2 Mappings](maps.md) |
| [6 DAK API Documentation Hub](dak-api.md) |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

