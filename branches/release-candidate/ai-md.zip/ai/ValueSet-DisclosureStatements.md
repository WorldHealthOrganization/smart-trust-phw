# Disclosure Statements - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Disclosure Statements**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Narrative Content](#) 
*  [XML](ValueSet-DisclosureStatements.xml.md) 
*  [JSON](ValueSet-DisclosureStatements.json.md) 
*  [TTL](ValueSet-DisclosureStatements.ttl.md) 

## ValueSet: Disclosure Statements 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/ValueSet/DisclosureStatements | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:DisclosureStatements |

 
Disclosure Statements value set 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

* Include all codes defined in [`http://smart.who.int/trust-phw/CodeSystem/DisclosureStatements`](CodeSystem-DisclosureStatements.md) version 📦0.1.0

 

### Expansion

Expansion performed internally based on [codesystem Disclosure Statements v0.1.0 (CodeSystem)](CodeSystem-DisclosureStatements.md)

This value set contains 13 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

