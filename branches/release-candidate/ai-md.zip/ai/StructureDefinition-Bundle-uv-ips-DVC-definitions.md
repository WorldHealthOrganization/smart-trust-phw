# DVC Certificate - DVC Bundle for Digital Vaccine Certificates - Definitions - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Certificate - DVC Bundle for Digital Vaccine Certificates**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](StructureDefinition-Bundle-uv-ips-DVC.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-Bundle-uv-ips-DVC-mappings.md) 
*  [XML](StructureDefinition-Bundle-uv-ips-DVC.profile.xml.md) 
*  [JSON](StructureDefinition-Bundle-uv-ips-DVC.profile.json.md) 
*  [TTL](StructureDefinition-Bundle-uv-ips-DVC.profile.ttl.md) 

## Resource Profile: Bundle-uv-ips-DVC - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-07 |

Definitions for the Bundle-uv-ips-DVC resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

