#  - GDHCN Trust Network - Personal Health Wallet v0.1.0

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](StructureDefinition-Immunization-uv-ips-PreQual.md) 
*  [Detailed Descriptions](StructureDefinition-Immunization-uv-ips-PreQual-definitions.md) 
*  [Mappings](StructureDefinition-Immunization-uv-ips-PreQual-mappings.md) 
*  [XML](StructureDefinition-Immunization-uv-ips-PreQual.profile.xml.md) 
*  [JSON](StructureDefinition-Immunization-uv-ips-PreQual.profile.json.md) 
*  [TTL](StructureDefinition-Immunization-uv-ips-PreQual.profile.ttl.md) 

## Resource Profile: Immunization-uv-ips-PreQual - Change History

| |
| :--- |
| Active as of 2025-10-07 |

Changes in the Immunization-uv-ips-PreQual resource profile.

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

