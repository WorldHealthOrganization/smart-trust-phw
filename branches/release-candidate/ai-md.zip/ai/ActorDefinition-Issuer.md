# Issuer - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Issuer**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Narrative Content](#) 
*  [XML](ActorDefinition-Issuer.xml.md) 
*  [JSON](ActorDefinition-Issuer.json.md) 
*  [TTL](ActorDefinition-Issuer.ttl.md) 

## ActorDefinition: Issuer (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/ActorDefinition/Issuer | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:Issuer |

 
Issuer (system) of[Verifiable Health Certificate](https://smart.who.int/trust/concepts.html#verifiable-digital-health-certificate)or[Verifiable Health Link](https://build.fhir.org/ig/IHE/ITI.VHL/branches/master/index.html) 

Profile: [SGActor](file://C:\work\ImplementationGuides\ig-release\who\smart-base\output/StructureDefinition-SGActor.html)

* **Actor: Issuer**: 
* **Actor: Issuer**: Derived from:
  * Issuer: [Trust Network Participant](ActorDefinition-TrustNetworkParticipant.md)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

