# SelectiveDisclosure - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **SelectiveDisclosure**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-SelectiveDisclosure-definitions.md) 
*  [Mappings](StructureDefinition-SelectiveDisclosure-mappings.md) 
*  [XML](StructureDefinition-SelectiveDisclosure.profile.xml.md) 
*  [JSON](StructureDefinition-SelectiveDisclosure.profile.json.md) 
*  [TTL](StructureDefinition-SelectiveDisclosure.profile.ttl.md) 

## Extension: SelectiveDisclosure 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:SelectiveDisclosure |

Guidance that a document signing service with selective disclosure support (e.g. SD-JWT) should perform a selective disclosure of the content of the containing node of the extension in the JSON representation of the FHIR instance.

The code value should be from a code system containing appropriate disclosure statements for the use case. The disclosure statement should describe the content that is to be disclosed at that node. For example a code such as 'disclose-date-of-birth' or 'disclose-vaccine-history'.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Digital Vaccination Certificate - Composition](StructureDefinition-DVCSDComposition.md), [DVC Immunization with Selective Disclosure](StructureDefinition-DVCSDImmunization.md), [DVC Patient with Selective Disclosure](StructureDefinition-DVCSDPatient.md) and [DVC Vaccine Details with Selective Disclosure](StructureDefinition-VaccineDetailsSD.md)
* Examples for this Extension: [Bundle/DVCDocSDExample](Bundle-DVCDocSDExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/SelectiveDisclosure)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type code: Guidance that a document signing service with selective disclosure support (e.g. SD-JWT) should perform a selective disclosure of the content of the containing node of the extension in the JSON representation of the FHIR instance.

The code value should be from a code system containing appropriate disclosure statements for the use case. The disclosure statement should describe the content that is to be disclosed at that node. For example a code such as 'disclose-date-of-birth' or 'disclose-vaccine-history'.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type code: Guidance that a document signing service with selective disclosure support (e.g. SD-JWT) should perform a selective disclosure of the content of the containing node of the extension in the JSON representation of the FHIR instance.

The code value should be from a code system containing appropriate disclosure statements for the use case. The disclosure statement should describe the content that is to be disclosed at that node. For example a code such as 'disclose-date-of-birth' or 'disclose-vaccine-history'.

 

Other representations of profile: [CSV](StructureDefinition-SelectiveDisclosure.csv), [Excel](StructureDefinition-SelectiveDisclosure.xlsx), [Schematron](StructureDefinition-SelectiveDisclosure.sch) 

#### Constraints

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

