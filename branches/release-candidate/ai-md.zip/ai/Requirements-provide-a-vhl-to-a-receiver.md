# Provide VHL or VDHC - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Provide VHL or VDHC**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Narrative Content](#) 
*  [XML](Requirements-provide-a-vhl-to-a-receiver.xml.md) 
*  [JSON](Requirements-provide-a-vhl-to-a-receiver.json.md) 
*  [TTL](Requirements-provide-a-vhl-to-a-receiver.ttl.md) 

## Requirements: Provide VHL or VDHC 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/Requirements/provide-a-vhl-to-a-receiver | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*: |

 
Is able to provide a VHL authorization mechanism or a VDHC to a VHL Receiver 

These requirements apply to the actor [Holder](ActorDefinition-Holder.md)

|
|

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

