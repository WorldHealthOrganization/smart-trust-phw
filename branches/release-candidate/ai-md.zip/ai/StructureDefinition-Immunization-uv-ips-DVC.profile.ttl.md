# DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set - TTL Representation - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](StructureDefinition-Immunization-uv-ips-DVC.md) 
*  [Detailed Descriptions](StructureDefinition-Immunization-uv-ips-DVC-definitions.md) 
*  [Mappings](StructureDefinition-Immunization-uv-ips-DVC-mappings.md) 
*  [XML](StructureDefinition-Immunization-uv-ips-DVC.profile.xml.md) 
*  [JSON](StructureDefinition-Immunization-uv-ips-DVC.profile.json.md) 
*  [TTL](#) 

## Resource Profile: Immunization-uv-ips-DVC - TTL Profile

| |
| :--- |
| Active as of 2025-10-07 |

TTL representation of the Immunization-uv-ips-DVC resource profile.

[Raw ttl](StructureDefinition-Immunization-uv-ips-DVC.ttl) | [Download](StructureDefinition-Immunization-uv-ips-DVC.ttl)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

