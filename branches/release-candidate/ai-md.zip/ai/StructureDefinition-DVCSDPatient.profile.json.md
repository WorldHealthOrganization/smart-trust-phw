# DVC Patient with Selective Disclosure - JSON Representation - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Patient with Selective Disclosure**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](StructureDefinition-DVCSDPatient.md) 
*  [Detailed Descriptions](StructureDefinition-DVCSDPatient-definitions.md) 
*  [Mappings](StructureDefinition-DVCSDPatient-mappings.md) 
*  [XML](StructureDefinition-DVCSDPatient.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-DVCSDPatient.profile.ttl.md) 

## Resource Profile: DVCSDPatient - JSON Profile

| |
| :--- |
| Draft as of 2025-10-07 |

JSON representation of the DVCSDPatient resource profile.

[Raw json](StructureDefinition-DVCSDPatient.json) | [Download](StructureDefinition-DVCSDPatient.json)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

