# DVC HCert Vaccine Details (Minimal) - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC HCert Vaccine Details (Minimal)**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCMinVaccineDetails-definitions.md) 
*  [Mappings](StructureDefinition-DVCMinVaccineDetails-mappings.md) 
*  [XML](StructureDefinition-DVCMinVaccineDetails.profile.xml.md) 
*  [JSON](StructureDefinition-DVCMinVaccineDetails.profile.json.md) 
*  [TTL](StructureDefinition-DVCMinVaccineDetails.profile.ttl.md) 

## Logical Model: DVC HCert Vaccine Details (Minimal) ( Abstract ) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCMinVaccineDetails | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:DVCMinVaccineDetails |

 
DVC Vaccine Details for a ininmial DVC payload for use within an HCERT Payload 

**Usages:**

* Derived from this Logical Model: [DVC HCERT Payload for PreQual DB](StructureDefinition-DVCMinVaccineDetailsPreQual.md)
* Use this Logical Model: [DVC HCERT Payload](StructureDefinition-DVCMin.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCMinVaccineDetails)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Constraints

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(3 nested mandatory elements)

 **Key Elements View** 

#### Constraints

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Constraints

 **Snapshot View** 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(3 nested mandatory elements)

 

Other representations of profile: [CSV](StructureDefinition-DVCMinVaccineDetails.csv), [Excel](StructureDefinition-DVCMinVaccineDetails.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

