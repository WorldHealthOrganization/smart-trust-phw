# DVC Certificate - IPS Composition - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Certificate - IPS Composition**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-Composition-uv-ips-DVC-definitions.md) 
*  [Mappings](StructureDefinition-Composition-uv-ips-DVC-mappings.md) 
*  [XML](StructureDefinition-Composition-uv-ips-DVC.profile.xml.md) 
*  [JSON](StructureDefinition-Composition-uv-ips-DVC.profile.json.md) 
*  [TTL](StructureDefinition-Composition-uv-ips-DVC.profile.ttl.md) 

## Resource Profile: DVC Certificate - IPS Composition 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/Composition-uv-ips-DVC | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:Composition-uv-ips-DVC |

 
Profile of the IPS Composition for representing digital vaccination certificates with 

**Usages:**

* Derived from this Profile: [DVC Certificate - IPS Composition for WHO PreQual Database](StructureDefinition-Composition-uv-ips-PreQual.md)
* Use this Profile: [DVC Certificate - DVC Bundle for Digital Vaccine Certificates](StructureDefinition-Bundle-uv-ips-DVC.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/Composition-uv-ips-DVC)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CompositionUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Composition-uv-ips.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [CompositionUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Composition-uv-ips.html) 

**Summary**

**Structures**

This structure refers to these other structures:

* [DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set(http://smart.who.int/trust-phw/StructureDefinition/Immunization-uv-ips-DVC)](StructureDefinition-Immunization-uv-ips-DVC.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [CompositionUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Composition-uv-ips.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [CompositionUvIps](http://hl7.org/fhir/uv/ips/2024Sep/StructureDefinition-Composition-uv-ips.html) 

**Summary**

**Structures**

This structure refers to these other structures:

* [DVC - Profile for Digitial Vaccination Cards for Immunization for IPS. Note that no Product Catalog has been set(http://smart.who.int/trust-phw/StructureDefinition/Immunization-uv-ips-DVC)](StructureDefinition-Immunization-uv-ips-DVC.md)

 

Other representations of profile: [CSV](StructureDefinition-Composition-uv-ips-DVC.csv), [Excel](StructureDefinition-Composition-uv-ips-DVC.xlsx), [Schematron](StructureDefinition-Composition-uv-ips-DVC.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

