# DVC document Bundle with Selective Disclosure - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC document Bundle with Selective Disclosure**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCSDBundle-definitions.md) 
*  [Mappings](StructureDefinition-DVCSDBundle-mappings.md) 
*  [Examples](StructureDefinition-DVCSDBundle-examples.md) 
*  [XML](StructureDefinition-DVCSDBundle.profile.xml.md) 
*  [JSON](StructureDefinition-DVCSDBundle.profile.json.md) 
*  [TTL](StructureDefinition-DVCSDBundle.profile.ttl.md) 

## Resource Profile: DVC document Bundle with Selective Disclosure 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCSDBundle | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:DVCSDBundle |

 
DVC document Bundle with Selective Disclosure for each entry 

**Usages:**

* Examples for this Profile: [Bundle/DVCDocSDExample](Bundle-DVCDocSDExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCSDBundle)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCBundle](StructureDefinition-DVCBundle.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCBundle](StructureDefinition-DVCBundle.md) 

**Summary**

**Structures**

This structure refers to these other structures:

* [Digital Vaccination Certificate - Composition(http://smart.who.int/trust-phw/StructureDefinition/DVCSDComposition)](StructureDefinition-DVCSDComposition.md)
* [DVC Patient with Selective Disclosure(http://smart.who.int/trust-phw/StructureDefinition/DVCSDPatient)](StructureDefinition-DVCSDPatient.md)
* [DVC Immunization with Selective Disclosure(http://smart.who.int/trust-phw/StructureDefinition/DVCSDImmunization)](StructureDefinition-DVCSDImmunization.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DVCBundle](StructureDefinition-DVCBundle.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCBundle](StructureDefinition-DVCBundle.md) 

**Summary**

**Structures**

This structure refers to these other structures:

* [Digital Vaccination Certificate - Composition(http://smart.who.int/trust-phw/StructureDefinition/DVCSDComposition)](StructureDefinition-DVCSDComposition.md)
* [DVC Patient with Selective Disclosure(http://smart.who.int/trust-phw/StructureDefinition/DVCSDPatient)](StructureDefinition-DVCSDPatient.md)
* [DVC Immunization with Selective Disclosure(http://smart.who.int/trust-phw/StructureDefinition/DVCSDImmunization)](StructureDefinition-DVCSDImmunization.md)

 

Other representations of profile: [CSV](StructureDefinition-DVCSDBundle.csv), [Excel](StructureDefinition-DVCSDBundle.xlsx), [Schematron](StructureDefinition-DVCSDBundle.sch) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

