# DVC Immunization with Selective Disclosure - Definitions - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Immunization with Selective Disclosure**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](StructureDefinition-DVCSDImmunization.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-DVCSDImmunization-mappings.md) 
*  [XML](StructureDefinition-DVCSDImmunization.profile.xml.md) 
*  [JSON](StructureDefinition-DVCSDImmunization.profile.json.md) 
*  [TTL](StructureDefinition-DVCSDImmunization.profile.ttl.md) 

## Resource Profile: DVCSDImmunization - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-07 |

Definitions for the DVCSDImmunization resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

