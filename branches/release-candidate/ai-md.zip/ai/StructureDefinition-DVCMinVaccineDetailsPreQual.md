# DVC HCERT Payload for PreQual DB - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC HCERT Payload for PreQual DB**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DVCMinVaccineDetailsPreQual-definitions.md) 
*  [Mappings](StructureDefinition-DVCMinVaccineDetailsPreQual-mappings.md) 
*  [XML](StructureDefinition-DVCMinVaccineDetailsPreQual.profile.xml.md) 
*  [JSON](StructureDefinition-DVCMinVaccineDetailsPreQual.profile.json.md) 
*  [TTL](StructureDefinition-DVCMinVaccineDetailsPreQual.profile.ttl.md) 

## Logical Model: DVC HCERT Payload for PreQual DB 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/DVCMinVaccineDetailsPreQual | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:DVCMinVaccineDetailsPreQual |

 
DVC payload for a minimal DVC for use within an HCERT Payload using the WHO PreQual Vaccine Database 

**Usages:**

* Use this Logical Model: [DVCMinPreQual](StructureDefinition-DVCMinPreQual.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/DVCMinVaccineDetailsPreQual)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCMinVaccineDetails](StructureDefinition-DVCMinVaccineDetails.md) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCMinVaccineDetails](StructureDefinition-DVCMinVaccineDetails.md) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DVCMinVaccineDetails](StructureDefinition-DVCMinVaccineDetails.md) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DVCMinVaccineDetails](StructureDefinition-DVCMinVaccineDetails.md) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-DVCMinVaccineDetailsPreQual.csv), [Excel](StructureDefinition-DVCMinVaccineDetailsPreQual.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

