# Trust Network Anchor - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trust Network Anchor**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Narrative Content](#) 
*  [XML](ActorDefinition-TrustNetworkAnchor.xml.md) 
*  [JSON](ActorDefinition-TrustNetworkAnchor.json.md) 
*  [TTL](ActorDefinition-TrustNetworkAnchor.ttl.md) 

## ActorDefinition: Trust Network Anchor (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/ActorDefinition/TrustNetworkAnchor | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:Trust Network Anchor |

 
Trust Anchor which receives and distributes PKI-material within a Trust Network 

Profile: [SGActor](file://C:\work\ImplementationGuides\ig-release\who\smart-base\output/StructureDefinition-SGActor.html)

* **Actor: Trust Network Anchor**: 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

