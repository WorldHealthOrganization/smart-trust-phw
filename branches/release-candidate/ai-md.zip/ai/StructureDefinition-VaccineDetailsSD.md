# DVC Vaccine Details with Selective Disclosure - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVC Vaccine Details with Selective Disclosure**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-VaccineDetailsSD-definitions.md) 
*  [Mappings](StructureDefinition-VaccineDetailsSD-mappings.md) 
*  [XML](StructureDefinition-VaccineDetailsSD.profile.xml.md) 
*  [JSON](StructureDefinition-VaccineDetailsSD.profile.json.md) 
*  [TTL](StructureDefinition-VaccineDetailsSD.profile.ttl.md) 

## Logical Model: DVC Vaccine Details with Selective Disclosure 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/VaccineDetailsSD | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:VaccineDetailsSD |

 
DVC Vaccine Details with Selective Disclosure 

**Usages:**

* This Logical Model Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/VaccineDetailsSD)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [VaccineDetails](StructureDefinition-VaccineDetails.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [VaccineDetails](StructureDefinition-VaccineDetails.md) 

**Summary**

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure](StructureDefinition-SelectiveDisclosure.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [VaccineDetails](StructureDefinition-VaccineDetails.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [VaccineDetails](StructureDefinition-VaccineDetails.md) 

**Summary**

**Extensions**

This structure refers to these extensions:

* [http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure](StructureDefinition-SelectiveDisclosure.md)

 

Other representations of profile: [CSV](StructureDefinition-VaccineDetailsSD.csv), [Excel](StructureDefinition-VaccineDetailsSD.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

