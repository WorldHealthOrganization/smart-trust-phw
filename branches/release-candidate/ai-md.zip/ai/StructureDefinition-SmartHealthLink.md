# Smart Health Link (DRAFT) - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Smart Health Link (DRAFT)**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-SmartHealthLink-definitions.md) 
*  [Mappings](StructureDefinition-SmartHealthLink-mappings.md) 
*  [XML](StructureDefinition-SmartHealthLink.profile.xml.md) 
*  [JSON](StructureDefinition-SmartHealthLink.profile.json.md) 
*  [TTL](StructureDefinition-SmartHealthLink.profile.ttl.md) 

## Logical Model: Smart Health Link (DRAFT) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/StructureDefinition/SmartHealthLink | *Version*:0.1.0 |
| Active as of 2025-10-07 | *Computable Name*:SmartHealthLink |

 
Smart Health Link URI (DRAFT) 
Logical Model to represent a SMART Health Link as its URI. It is generated from the content of the SMART Health Link Payload. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.trust-phw|current/StructureDefinition/SmartHealthLink)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(1 nested mandatory element)

 **Key Elements View** 

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(1 nested mandatory element)

 

Other representations of profile: [CSV](StructureDefinition-SmartHealthLink.csv), [Excel](StructureDefinition-SmartHealthLink.xlsx) 

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

