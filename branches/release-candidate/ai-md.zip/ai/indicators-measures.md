# Indicators and Measures - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Data Models and Exchange**](data-models-and-exchange.md)
* **Indicators and Measures**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

## Indicators and Measures

The FHIR Measure is used to describe the indicator in a computable format. These indicators may be aggregated automatically from the digital tracking tool to populate a digital health management information system (HMIS).

Measures included in this implementation guide are listed in the [Artifact Index - Measures](artifacts.md)

For the operational descriptions of indicators and references, see the Digital Adaptation Kit (DAK) for **[insert health domain here]**, including Web Annex C of the DAK. Summary indicator content from the DAK is also represented in the [Indicators and Performance Metrics](indicators.md) page.

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

