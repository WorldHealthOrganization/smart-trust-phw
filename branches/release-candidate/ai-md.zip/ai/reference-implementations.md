# Reference Implementations - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Deployment**](deployment.md)
* **Reference Implementations**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

## Reference Implementations

* [Reference applications](#reference-applications)
* [Reference architecture](#reference-architecture)

This page includes sample resources that can be leveraged to support the implementation of SMART Guidelines for **[insert health domain here]**. Content is for demonstration purposes only.

Additional relevant resources are included in the [References](references.md) and [Dependencies](dependencies.md).

### Reference applications

### Reference architecture

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

