# Codings - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Data Models and Exchange**](data-models-and-exchange.md)
* **Codings**

GDHCN Trust Network - Personal Health Wallet, published by WHO. This guide is not an authorized publication; it is the continuous build for version 0.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate](https://github.com/WorldHealthOrganization/smart-trust-phw/tree/release-candidate) and changes regularly. See the [Directory of published versions](http://smart.who.int/trust-phw/history.html)

## Codings

* [CodeSystems](#codesystems)
* [ValueSets](#valuesets)

Note that the terminologies included in this implementation guide will need to be updated, because the ideal mechanism for distribution (as an expression) is not currently supported by the content logical definition constructs available in the FHIR ValueSet resource and all known implementations of it. Before use in a production environment, ensure you have the latest value sets based on the definitions for each value set (as defined in the inclusion/exclusion criteria for each one).

The following terminology artifacts are included for this implementation guide:

### CodeSystems

* [Relationship Status for Contact in Patient](CodeSystem-DVCRelationshipStatus.md)

* [Disclosure Statements](CodeSystem-DisclosureStatements.md)

* [Smart Guidelines Documentation Section](CodeSystem-DocumentationSections.md)

* [HL Type CodeSystem](CodeSystem-HL.TYPE.md)

### ValueSets

* [Relationship Status for Contact in Patient](ValueSet-DVCRelationshipStatus.md)

* [DVC - Vaccines](ValueSet-DVCVaccines.md)

* [Disclosure Statements](ValueSet-DisclosureStatements.md)

* [HL.TYPE ValueSet](ValueSet-HL.TYPE.md)

 IG © 2023+ [WHO](http://who.int). Package smart.who.int.trust-phw#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)|[Version History](http://smart.who.int/trust-phw/history.html)|[License](license.md) 

