# smart.who.int.trust-phw#0.1.0: GDHCN Trust Network - Personal Health Wallet

## Pages

* [Home](index.md)
* [Functional Requirements](functional-requirements.md)
* [Indicators and Measures](indicators-measures.md)
* [Test Data](test-data.md)
* [Testing](testing.md)
* [Indicator and Performance Metrics](indicators.md)
* [DAK API Documentation Hub](dak-api.md)
* [Generic Personas](personas.md)
* [Transactions](transactions.md)
* [Dependencies](dependencies.md)
* [Codings](codings.md)
* [Adapting Guidelines for Country use](adapting.md)
* [Concepts](concepts.md)
* [System Actors](system-actors.md)
* [Sequence Diagrams](sequence-diagrams.md)
* [Trust Domains](trust_domain.md)
* [Decision-support logic](decision-logic.md)
* [Artifact Index](artifacts.md)
* [Business Requirements](business-requirements.md)
* [Mappings](maps.md)
* [References](references.md)
* [Data Dictionary](dictionary.md)
* [User Scenarios](scenarios.md)
* [Changes](changes.md)
* [Deployment](deployment.md)
* [Reference Implementations](reference-implementations.md)
* [Indices](indices.md)
* [Downloads](downloads.md)
* [Security and Privacy Considerations](security-privacy.md)
* [License](license.md)
* [Data Models and Exchange](data-models-and-exchange.md)
* [Non-functional Requirements](non-functional-requirements.md)
* [Business Processes](business-processes.md)

## Resources

### CodeSystems

* [Relationship Status for Contact in Patient](CodeSystem-DVCRelationshipStatus.md)
* [Disclosure Statements](CodeSystem-DisclosureStatements.md)
* [Smart Guidelines Documentation Section](CodeSystem-DocumentationSections.md)
* [HL Type CodeSystem](CodeSystem-HL.TYPE.md)

### ValueSets

* [Relationship Status for Contact in Patient](ValueSet-DVCRelationshipStatus.md)
* [DVC - Vaccines](ValueSet-DVCVaccines.md)
* [Disclosure Statements](ValueSet-DisclosureStatements.md)
* [HL.TYPE ValueSet ](ValueSet-HL.TYPE.md)

### Logicals

* [DVC](StructureDefinition-DVC.md)
* [DVC HCERT Payload](StructureDefinition-DVCMin.md)
* [DVCMinPreQual](StructureDefinition-DVCMinPreQual.md)
* [DVC HCert Vaccine Details (Minimal)](StructureDefinition-DVCMinVaccineDetails.md)
* [DVC HCERT Payload for PreQual DB](StructureDefinition-DVCMinVaccineDetailsPreQual.md)
* [PreQual](StructureDefinition-DVCPreQual.md)
* [DVC - Vaccine Details](StructureDefinition-DVCVaccineDetails.md)
* [PreQual - Vaccine Details](StructureDefinition-DVCVaccineDetailsPreQual.md)
* [Health Link Payload (DRAFT)](StructureDefinition-HealthLinkPayload.md)
* [SMART Health Link Payload (DRAFT)](StructureDefinition-SMARTHealthLinkPayload.md)
* [Smart Health Link (DRAFT)](StructureDefinition-SmartHealthLink.md)
* [Verifiable Health Link Payload (DRAFT)](StructureDefinition-VerifiableHealthLinkPayload.md)

### Logical Profiles

* [DVC with Selective Disclosure](StructureDefinition-DVCSD.md)
* [DVC Vaccine Details with Selective Disclosure](StructureDefinition-VaccineDetailsSD.md)

### Resource Profiles

* [DVC Certificate - DVC Bundle for Digital Vaccine Certificates](StructureDefinition-Bundle-uv-ips-DVC.md)
* [DVC Certificate - IPS Bundle for WHO PreQual Databae](StructureDefinition-Bundle-uv-ips-PreQual.md)
* [DVC Certificate - IPS Composition ](StructureDefinition-Composition-uv-ips-DVC.md)
* [DVC Certificate - IPS Composition for WHO PreQual Database](StructureDefinition-Composition-uv-ips-PreQual.md)
* [Digital Vaccination Certificate - Bundle](StructureDefinition-DVCBundle.md)
* [Digital Vaccination Certificate - Composition](StructureDefinition-DVCComposition.md)
* [DVC Immunization](StructureDefinition-DVCImmunization.md)
* [DVC Patient](StructureDefinition-DVCPatient.md)
* [DVC document Bundle with Selective Disclosure](StructureDefinition-DVCSDBundle.md)
* [Digital Vaccination Certificate - Composition](StructureDefinition-DVCSDComposition.md)
* [DVC Immunization with Selective Disclosure](StructureDefinition-DVCSDImmunization.md)
* [DVC Patient with Selective Disclosure](StructureDefinition-DVCSDPatient.md)
* [DVC - Profile for Digital Vaccination Cards for Immunization for IPS.  Note that no Product Catalog has been set](StructureDefinition-Immunization-uv-ips-DVC.md)
* [DVC - WHO PreQual Immunization for IPS](StructureDefinition-Immunization-uv-ips-PreQual.md)

### Extensions

* [DoseNumberCodeableConcept](StructureDefinition-DoseNumberCodeableConcept.md)
* [SGActorExt](StructureDefinition-SGActorExt.md)
* [SelectiveDisclosure](StructureDefinition-SelectiveDisclosure.md)

### ActorDefinitions

* [Consent Registry](ActorDefinition-ConsentRegistry.md)
* [Holder](ActorDefinition-Holder.md)
* [Issuer](ActorDefinition-Issuer.md)
* [Receiver](ActorDefinition-Receiver.md)
* [Trust Network Anchor](ActorDefinition-TrustNetworkAnchor.md)
* [Trust Network Participant](ActorDefinition-TrustNetworkParticipant.md)

### ImplementationGuides

* [GDHCN Trust Network - Personal Health Wallet](index.md)

### Questionnaires

* [DVC Model Questionnaire](Questionnaire-PreQual.md)

### Requirements

* [Accept mTLS](Requirements-accept-mtls-connection.md)
* [Distribute PKI material](Requirements-distribute-pki-material.md)
* [Initiate mTLS](Requirements-initiate-mtls-connection.md)
* [Provide VHL or VDHC](Requirements-provide-a-vhl-to-a-receiver.md)
* [Publish PKI material](Requirements-publish-pki-material.md)
* [Receive VHL or VDHC](Requirements-receive-a-vhl.md)
* [Receive PKI material](Requirements-receive-pki-material.md)
* [Retrieve PKI material](Requirements-retrieve-pki-material.md)

### Examples

* [DVCExample (Binary)](Binary-DVCExample.md)
* [DVCDocExample (Bundle)](Bundle-DVCDocExample.md)
* [DVCDocSDExample (Bundle)](Bundle-DVCDocSDExample.md)
* [Manufacturer A (Organization)](Organization-ExampleManufacturerOrg.md)
