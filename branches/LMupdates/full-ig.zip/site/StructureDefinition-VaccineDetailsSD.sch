<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile DVCVaccineDetails
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:DVCVaccineDetails/f:vaccine</sch:title>
    <sch:rule context="f:DVCVaccineDetails/f:vaccine">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure']) &lt;= 1">extension with URL = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:concept) &lt;= 1">concept: maximum cardinality of 'concept' is 1</sch:assert>
      <sch:assert test="count(f:reference) &lt;= 1">reference: maximum cardinality of 'reference' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:DVCVaccineDetails/f:date</sch:title>
    <sch:rule context="f:DVCVaccineDetails/f:date">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure']) &lt;= 1">extension with URL = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:value) &lt;= 1">value: maximum cardinality of 'value' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:DVCVaccineDetails/f:issuer</sch:title>
    <sch:rule context="f:DVCVaccineDetails/f:issuer">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure']) &lt;= 1">extension with URL = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:reference) &lt;= 1">reference: maximum cardinality of 'reference' is 1</sch:assert>
      <sch:assert test="count(f:type) &lt;= 1">type: maximum cardinality of 'type' is 1</sch:assert>
      <sch:assert test="count(f:identifier) &lt;= 1">identifier: maximum cardinality of 'identifier' is 1</sch:assert>
      <sch:assert test="count(f:display) &lt;= 1">display: maximum cardinality of 'display' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:DVCVaccineDetails/f:clinicianName</sch:title>
    <sch:rule context="f:DVCVaccineDetails/f:clinicianName">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure']) &lt;= 1">extension with URL = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:value) &lt;= 1">value: maximum cardinality of 'value' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:DVCVaccineDetails/f:manufacturer</sch:title>
    <sch:rule context="f:DVCVaccineDetails/f:manufacturer">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure']) &lt;= 1">extension with URL = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:reference) &lt;= 1">reference: maximum cardinality of 'reference' is 1</sch:assert>
      <sch:assert test="count(f:type) &lt;= 1">type: maximum cardinality of 'type' is 1</sch:assert>
      <sch:assert test="count(f:identifier) &lt;= 1">identifier: maximum cardinality of 'identifier' is 1</sch:assert>
      <sch:assert test="count(f:display) &lt;= 1">display: maximum cardinality of 'display' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:DVCVaccineDetails/f:batchNo</sch:title>
    <sch:rule context="f:DVCVaccineDetails/f:batchNo">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure']) &lt;= 1">extension with URL = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:text) &lt;= 1">text: maximum cardinality of 'text' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:DVCVaccineDetails/f:validity</sch:title>
    <sch:rule context="f:DVCVaccineDetails/f:validity">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure']) &lt;= 1">extension with URL = 'http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:start) &lt;= 1">start: maximum cardinality of 'start' is 1</sch:assert>
      <sch:assert test="count(f:end) &lt;= 1">end: maximum cardinality of 'end' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
