# Relationship Status for Contact in Patient - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Relationship Status for Contact in Patient**

## ValueSet: Relationship Status for Contact in Patient 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/ValueSet/DVCRelationshipStatus | *Version*:0.1.0 |
| Draft as of 2026-10-20 | *Computable Name*:DVCRelationshipStatus |

 
Relationship Status for Contact in Patient 

 **References** 

* [DVC Patient](StructureDefinition-DVCPatient.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### Relationship Status for Contact in Patient Schema API

JSON Schema for Relationship Status for Contact in Patient ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-DVCRelationshipStatus.schema.json

#### JSON Schema definition for the enumeration ValueSet-DVCRelationshipStatus

This endpoint serves the JSON Schema definition for the enumeration ValueSet-DVCRelationshipStatus.

## Schema Definition

### ValueSet-DVCRelationshipStatus

**Description:** JSON Schema for Relationship Status for Contact in Patient ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "DVCRelationshipStatus",
  "url" : "http://smart.who.int/trust-phw/ValueSet/DVCRelationshipStatus",
  "version" : "0.1.0",
  "name" : "DVCRelationshipStatus",
  "title" : "Relationship Status for Contact in Patient",
  "status" : "draft",
  "date" : "2026-10-20T16:42:03+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Relationship Status for Contact in Patient",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/trust-phw/CodeSystem/DVCRelationshipStatus"
    }]
  }
}

```
