# Disclosure Statements - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Disclosure Statements**

## CodeSystem: Disclosure Statements 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/CodeSystem/DisclosureStatements | *Version*:0.1.0 |
| Active as of 2026-10-20 | *Computable Name*:DisclosureStatements |

 
Disclosure Statement Code System 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Disclosure Statements](ValueSet-DisclosureStatements.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "DisclosureStatements",
  "url" : "http://smart.who.int/trust-phw/CodeSystem/DisclosureStatements",
  "version" : "0.1.0",
  "name" : "DisclosureStatements",
  "title" : "Disclosure Statements",
  "status" : "active",
  "date" : "2026-10-20T16:42:03+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Disclosure Statement Code System",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "content" : "complete",
  "count" : 13,
  "concept" : [{
    "code" : "disclose-icvp",
    "display" : "Disclose ICVP ",
    "definition" : "Agree to disclose the full details of your vaccination history and demogrpahic information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-narrative",
    "display" : "Disclose ICVP narrative",
    "definition" : "Agree to disclose a narrative summary of your vaccination history as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-demographic",
    "display" : "Disclose full details of ICVP demograhic narrative",
    "definition" : "Agree to disclose full details your demographic information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-demographic-narrative",
    "display" : "Disclose ICVP demograhic narrative",
    "definition" : "Agree to disclose a narrative summary of your demographic information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-demographic-name",
    "display" : "Disclose name",
    "definition" : "Agree to disclose name from demographic issuer information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-demographic-sex",
    "display" : "Disclose sex",
    "definition" : "Agree to disclose sex from demographic issuer information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-demographic-dob",
    "display" : "Disclose date of birth",
    "definition" : "Agree to disclose date of birth from demographic issuer information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-demographic-nationality",
    "display" : "Disclose nationality",
    "definition" : "Agree to disclose nationality from demographic issuer information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-demographic-national-id",
    "display" : "Disclose national ID",
    "definition" : "Agree to disclose national ID or passport number from demographic issuer information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-vaccination",
    "display" : "Disclose ICVP vaccination",
    "definition" : "Agree to disclose the full details of your vaccination history as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-vaccination-narrative",
    "display" : "Disclose ICVP vaccination narrative",
    "definition" : "Agree to disclose a narrative summary of your vaccination information as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-vaccination-clinician",
    "display" : "Disclose clinician name",
    "definition" : "Agree to disclose clinician name for this vaccination as is contained in the International Certification of Vaccination or Prophylaxsis"
  },
  {
    "code" : "disclose-icvp-vaccination-issuer",
    "display" : "Disclose issuer",
    "definition" : "Agree to disclose issuer for this vaccination as is contained in the International Certification of Vaccination or Prophylaxsis"
  }]
}

```
