# Trust Network Anchor - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Trust Network Anchor**

## ActorDefinition: Trust Network Anchor (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/trust-phw/ActorDefinition/TrustNetworkAnchor | *Version*:0.1.0 |
| Active as of 2026-10-20 | *Computable Name*:Trust Network Anchor |

 
Trust Anchor which receives and distributes PKI-material within a Trust Network 



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "TrustNetworkAnchor",
  "meta" : {
    "profile" : ["http://smart.who.int/base/StructureDefinition/SGActor"]
  },
  "url" : "http://smart.who.int/trust-phw/ActorDefinition/TrustNetworkAnchor",
  "version" : "0.1.0",
  "name" : "Trust Network Anchor",
  "title" : "Trust Network Anchor",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-20T16:42:03+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "Trust Anchor which receives and distributes PKI-material within a Trust Network",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "type" : "system"
}

```
