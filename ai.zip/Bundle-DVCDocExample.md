# DVCDocExample - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVCDocExample**

## Example Bundle: DVCDocExample



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "DVCDocExample",
  "meta" : {
    "profile" : ["http://smart.who.int/trust-phw/StructureDefinition/DVCBundle"]
  },
  "language" : "en-GB",
  "identifier" : {
    "system" : "urn:oid:2.16.724.4.8.10.200.10",
    "value" : "175bd032-8b00-4728-b2dc-748bb1501aed"
  },
  "type" : "document",
  "timestamp" : "2024-02-11T11:32:00+01:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:24351938-53ea-4d4f-b07b-7f557656005e",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "24351938-53ea-4d4f-b07b-7f557656005e",
      "meta" : {
        "profile" : ["http://smart.who.int/trust-phw/StructureDefinition/DVCComposition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_24351938-53ea-4d4f-b07b-7f557656005e\"> </a>To be added</div>"
      },
      "identifier" : [{
        "system" : "urn:oid:2.16.724.4.8.10.200.10",
        "value" : "d348b02a-3ab8-4cec-bbec-5186abca8c7d"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "82593-5",
          "display" : "Immunization summary report"
        }]
      },
      "subject" : [{
        "reference" : "urn:uuid:175863f7-fdea-4d11-92ff-f33345a560e4"
      }],
      "date" : "2017-12-11T14:30:00+01:00",
      "author" : [{
        "reference" : "urn:uuid:1c616b24-3895-48c4-9a02-9a64110351ef"
      }],
      "title" : "Patient Summary as of December 11, 2017 14:30",
      "section" : [{
        "title" : "Demographic information section",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "45970-1",
            "display" : "Demographic information section"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Sample patient</div>"
        },
        "entry" : [{
          "reference" : "Patient/175863f7-fdea-4d11-92ff-f33345a560e4"
        }]
      },
      {
        "title" : "Vaccination",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11369-6",
            "display" : "History of Immunization note"
          }]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Vaccination stuff</div>"
        },
        "entry" : [{
          "reference" : "Immunization/bc283f8f-7092-4cc1-9d4d-8928b0341d00"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:175863f7-fdea-4d11-92ff-f33345a560e4",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "175863f7-fdea-4d11-92ff-f33345a560e4",
      "meta" : {
        "profile" : ["http://smart.who.int/trust-phw/StructureDefinition/DVCPatient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_175863f7-fdea-4d11-92ff-f33345a560e4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 175863f7-fdea-4d11-92ff-f33345a560e4</b></p><a name=\"175863f7-fdea-4d11-92ff-f33345a560e4\"> </a><a name=\"hc175863f7-fdea-4d11-92ff-f33345a560e4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-DVCPatient.html\">DVC Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Test Patient(official) Female, DoB: 2023-02-04 ( Passport number)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The nationality of the patient.\">Patient Nationality:</td><td colspan=\"3\"><ul><li>code: <span title=\"Codes:\">IND</span></li></ul></td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "code" : "IND"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/patient-nationality"
      }],
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PPN"
          }]
        },
        "system" : "https://uidai.gov.in/",
        "value" : "123456789012"
      }],
      "active" : true,
      "name" : [{
        "use" : "official",
        "text" : "Test Patient"
      }],
      "gender" : "female",
      "birthDate" : "2023-02-04"
    }
  },
  {
    "fullUrl" : "urn:uuid:bc283f8f-7092-4cc1-9d4d-8928b0341d00",
    "resource" : {
      "resourceType" : "Immunization",
      "id" : "bc283f8f-7092-4cc1-9d4d-8928b0341d00",
      "meta" : {
        "profile" : ["http://smart.who.int/trust-phw/StructureDefinition/DVCImmunization"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_bc283f8f-7092-4cc1-9d4d-8928b0341d00\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Immunization bc283f8f-7092-4cc1-9d4d-8928b0341d00</b></p><a name=\"bc283f8f-7092-4cc1-9d4d-8928b0341d00\"> </a><a name=\"hcbc283f8f-7092-4cc1-9d4d-8928b0341d00\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-DVCImmunization.html\">DVC Immunization</a></p></div><p><b>ProductID</b>: <a href=\"https://build.fhir.org/ig/WorldHealthOrganization/smart-pcmt-vaxprequal/CodeSystem-PreQualProductIds.html#PreQualProductIds-YellowFeverProductd2c75a15ed309658b3968519ddb31690\">WHO PreQualificaiton Vaccine Product Ids: YellowFeverProductd2c75a15ed309658b3968519ddb31690</a> (YellowFeverProductd2c75a15ed309658b3968519ddb31690)</p><p><b>status</b>: Completed</p><p><b>vaccineCode</b>: <span title=\"Codes:\">XM0N24</span></p><p><b>lotNumber</b>: 67890</p><p><b>patient</b>: <a href=\"Bundle-DVCDocExample.html#urn-uuid-175863f7-fdea-4d11-92ff-f33345a560e4\">Test Patient(official) Female, DoB: 2023-02-04 ( Passport number)</a></p><p><b>occurrence</b>: 2024-05-23</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><code>urn:uuid:086a66bd-63d0-442a-900f-b540f6b8cebe</code></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://smart.who.int/pcmt/StructureDefinition/ProductID",
        "valueCoding" : {
          "system" : "http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualProductIds",
          "code" : "YellowFeverProductd2c75a15ed309658b3968519ddb31690"
        }
      }],
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "code" : "XM0N24"
        }]
      },
      "lotNumber" : "67890",
      "patient" : {
        "reference" : "urn:uuid:175863f7-fdea-4d11-92ff-f33345a560e4"
      },
      "occurrenceDateTime" : "2024-05-23",
      "performer" : [{
        "actor" : {
          "reference" : "urn:uuid:086a66bd-63d0-442a-900f-b540f6b8cebe"
        }
      }]
    }
  }]
}

```
