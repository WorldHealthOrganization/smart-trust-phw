# DVCDocSDExample - GDHCN Trust Network - Personal Health Wallet v0.1.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **DVCDocSDExample**

## Example Bundle: DVCDocSDExample



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "DVCDocSDExample",
  "meta" : {
    "profile" : ["http://smart.who.int/trust-phw/StructureDefinition/DVCSDBundle"]
  },
  "language" : "en-GB",
  "identifier" : {
    "system" : "urn:oid:2.16.724.4.8.10.200.10",
    "value" : "157bd032-8b00-4728-b2dc-748bb1501aed"
  },
  "type" : "document",
  "timestamp" : "2024-02-11T11:32:00+01:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:23451938-53ea-4d4f-b07b-7f557656005e",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "23451938-53ea-4d4f-b07b-7f557656005e",
      "meta" : {
        "profile" : ["http://smart.who.int/trust-phw/StructureDefinition/DVCSDComposition"]
      },
      "text" : {
        "extension" : [{
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-narrative"
        }],
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_23451938-53ea-4d4f-b07b-7f557656005e\"> </a>To be added</div>"
      },
      "extension" : [{
        "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
        "valueCode" : "disclose-icvp"
      }],
      "identifier" : [{
        "system" : "urn:oid:2.16.724.4.8.10.200.10",
        "value" : "d348b02a-3ab8-4cec-bbec-5186abca8c7d"
      }],
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "82593-5",
          "display" : "Immunization summary report"
        }]
      },
      "subject" : [{
        "reference" : "urn:uuid:157863f7-fdea-4d11-92ff-f33345a560e4"
      }],
      "date" : "2017-12-11T14:30:00+01:00",
      "author" : [{
        "reference" : "urn:uuid:1c616b24-3895-48c4-9a02-9a64110351ef"
      }],
      "title" : "Patient Summary as of December 11, 2017 14:30",
      "section" : [{
        "title" : "Patient",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "45970-1"
          }]
        },
        "text" : {
          "extension" : [{
            "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
            "valueCode" : "disclose-icvp-demographic-narrative"
          }],
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Sample patient</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:157863f7-fdea-4d11-92ff-f33345a560e4"
        }]
      },
      {
        "title" : "Vaccination",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "11369-6",
            "display" : "History of Immunization note"
          }]
        },
        "text" : {
          "extension" : [{
            "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
            "valueCode" : "disclose-icvp-vaccination-narrative"
          }],
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\">Vaccination stuff</div>"
        },
        "entry" : [{
          "reference" : "urn:uuid:bc283f8f-0279-4cc1-9d4d-8928b0341d00"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:157863f7-fdea-4d11-92ff-f33345a560e4",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "157863f7-fdea-4d11-92ff-f33345a560e4",
      "meta" : {
        "profile" : ["http://smart.who.int/trust-phw/StructureDefinition/DVCSDPatient"]
      },
      "text" : {
        "extension" : [{
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-demographic-narrative"
        }],
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_157863f7-fdea-4d11-92ff-f33345a560e4\"> </a>Test Patient name and demographics</div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "code" : "IND"
            }]
          }
        },
        {
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-demographic-nationality"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/patient-nationality"
      },
      {
        "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
        "valueCode" : "disclose-icvp-demographic"
      }],
      "identifier" : [{
        "extension" : [{
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-demographic-national-id"
        }],
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PPN"
          }]
        },
        "system" : "https://uidai.gov.in/",
        "value" : "123456789012"
      }],
      "active" : true,
      "name" : [{
        "extension" : [{
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-demographic-name"
        }],
        "use" : "official",
        "text" : "Test Patient"
      }],
      "gender" : "female",
      "_gender" : {
        "extension" : [{
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-demographic-sex"
        }]
      },
      "birthDate" : "2023-02-04",
      "_birthDate" : {
        "extension" : [{
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-demographic-dob"
        }]
      }
    }
  },
  {
    "fullUrl" : "urn:uuid:bc283f8f-0279-4cc1-9d4d-8928b0341d00",
    "resource" : {
      "resourceType" : "Immunization",
      "id" : "bc283f8f-0279-4cc1-9d4d-8928b0341d00",
      "meta" : {
        "profile" : ["http://smart.who.int/trust-phw/StructureDefinition/DVCSDImmunization"]
      },
      "text" : {
        "extension" : [{
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-vaccination-narrative"
        }],
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Immunization_bc283f8f-0279-4cc1-9d4d-8928b0341d00\"> </a>vaccination event details</div>"
      },
      "extension" : [{
        "url" : "http://smart.who.int/pcmt/StructureDefinition/ProductID",
        "valueCoding" : {
          "system" : "http://smart.who.int/pcmt-vaxprequal/CodeSystem/PreQualProductIds",
          "code" : "YellowFeverProductd2c75a15ed309658b3968519ddb31690"
        }
      },
      {
        "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
        "valueCode" : "disclose-icvp-vaccination"
      }],
      "status" : "completed",
      "vaccineCode" : {
        "coding" : [{
          "code" : "XM0N24"
        }]
      },
      "lotNumber" : "67890",
      "patient" : {
        "reference" : "urn:uuid:157863f7-fdea-4d11-92ff-f33345a560e4"
      },
      "occurrenceDateTime" : "2024-05-23",
      "performer" : [{
        "extension" : [{
          "url" : "http://smart.who.int/trust-phw/StructureDefinition/SelectiveDisclosure",
          "valueCode" : "disclose-icvp-vaccination-clinician"
        }],
        "actor" : {
          "reference" : "urn:uuid:086a66bd-63d0-442a-900f-b540f6b8cebe"
        }
      }]
    }
  }]
}

```
